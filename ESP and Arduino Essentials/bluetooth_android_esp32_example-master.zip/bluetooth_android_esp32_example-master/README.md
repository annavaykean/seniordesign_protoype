# esp32 arduino android ble example

There are so many examples for ESP32 bluetooth servers but I could not find an example code to send data from Android app to ESP32 Bluetooth server so I made one.

1. ESP32 code is in bluetooth_android_esp32. I made it on PlatformIO. You can just copy and code in Arduino as well.

2. Android code is in android_app. Make sure you to grant bluetooth permission to connect 

Made this for my up coming project SR2

Enjoy
