package com.sinric.esp32_android_app;

public interface OnBluetoothDeviceClickedListener {
    void onBluetoothDeviceClicked(String name, String address);
}
